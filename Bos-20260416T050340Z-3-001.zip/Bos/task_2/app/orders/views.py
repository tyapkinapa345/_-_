from django.http import HttpResponse
from django.db.models import Avg, F, ExpressionWrapper, DurationField
from .models import Order


def average_delivery_time(request):
    avg_time = Order.objects.filter(
        delivered_at__isnull=False
    ).annotate(
        delivery_time=ExpressionWrapper(
            F('delivered_at') - F('created_at'),
            output_field=DurationField()
        )
    ).aggregate(
        average_delivery=Avg('delivery_time')
    )['average_delivery']

    if avg_time is None:
        return HttpResponse("Нет доставленных заказов")

    return HttpResponse(f"Среднее время доставки: {avg_time}")
