from django.db import models


class Order(models.Model):
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Время создания")
    delivered_at = models.DateTimeField(null=True, blank=True, verbose_name="Время доставки")

    def __str__(self):
        return f"Order #{self.id}"
