const mysql = require('mysql2');

const pool = mysql.createPool({
  host: 'db',
  user: 'botuser',
  password: 'botpass123',
  database: 'support_bot_db',
  charset: 'utf8mb4',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

module.exports = pool;
