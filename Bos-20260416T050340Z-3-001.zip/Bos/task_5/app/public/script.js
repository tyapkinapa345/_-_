window.addEventListener('load', function () {
  const form = document.getElementById('messageForm');
  const responseBlock = document.getElementById('responseBlock');
  const responseText = document.getElementById('responseText');
  const loadStatsBtn = document.getElementById('loadStatsBtn');
  const statsBlock = document.getElementById('statsBlock');
  const statsTableBody = document.getElementById('statsTableBody');

  console.log('script.js загружен');

  form.addEventListener('submit', async function (event) {
    event.preventDefault();
    console.log('Форма отправлена');

    const client_name = document.getElementById('client_name').value.trim();
    const message_text = document.getElementById('message_text').value.trim();

    responseBlock.classList.remove('hidden');
    responseText.textContent = 'Отправка...';

    try {
      const response = await fetch('/message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ client_name, message_text })
      });

      console.log('Статус ответа /message:', response.status);

      const data = await response.json();
      console.log('Ответ /message:', data);

      if (!response.ok) {
        responseText.textContent = data.error || 'Ошибка при отправке';
        return;
      }

      responseText.textContent = data.bot_reply;
      form.reset();
    } catch (error) {
      console.error('Ошибка fetch /message:', error);
      responseText.textContent = 'Ошибка соединения с сервером';
    }
  });

  loadStatsBtn.addEventListener('click', async function () {
    console.log('Нажата кнопка статистики');

    statsBlock.classList.remove('hidden');
    statsTableBody.innerHTML = '<tr><td colspan="2">Загрузка...</td></tr>';

    try {
      const response = await fetch('/stats');
      console.log('Статус ответа /stats:', response.status);

      const data = await response.json();
      console.log('Ответ /stats:', data);

      statsTableBody.innerHTML = '';

      if (!Array.isArray(data) || data.length === 0) {
        statsTableBody.innerHTML = '<tr><td colspan="2">Нет данных</td></tr>';
        return;
      }

      data.forEach((item) => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${item.client_name}</td>
          <td>${item.request_count}</td>
        `;
        statsTableBody.appendChild(row);
      });
    } catch (error) {
      console.error('Ошибка fetch /stats:', error);
      statsTableBody.innerHTML = '<tr><td colspan="2">Ошибка загрузки статистики</td></tr>';
    }
  });
});
