CREATE DATABASE IF NOT EXISTS support_bot_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE support_bot_db;

CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_name VARCHAR(100) NOT NULL,
    message_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
