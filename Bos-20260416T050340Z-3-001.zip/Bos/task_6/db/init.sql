CREATE TABLE IF NOT EXISTS demand (
    id SERIAL PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(100) NOT NULL,
    demand_value NUMERIC(10,2) NOT NULL
);

INSERT INTO demand (product_name, category, demand_value) VALUES
('iPhone 14', 'Смартфоны', 120),
('Samsung Galaxy S23', 'Смартфоны', 100),
('Lenovo ThinkPad', 'Ноутбуки', 80),
('MacBook Air', 'Ноутбуки', 90),
('LG OLED TV', 'Телевизоры', 60),
('Samsung QLED TV', 'Телевизоры', 70);
