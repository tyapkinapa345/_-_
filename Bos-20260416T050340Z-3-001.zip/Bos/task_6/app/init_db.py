import os
import psycopg2


def get_connection():
    return psycopg2.connect(
        dbname=os.getenv("POSTGRES_DB"),
        user=os.getenv("POSTGRES_USER"),
        password=os.getenv("POSTGRES_PASSWORD"),
        host=os.getenv("DB_HOST"),
        port=os.getenv("DB_PORT")
    )


def test_connection():
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT version();")
        version = cur.fetchone()
        print("Подключение к PostgreSQL успешно:", version)
        cur.close()
        conn.close()
    except Exception as e:
        print("Ошибка подключения:", e)


if name == "__main__":
    test_connection()
