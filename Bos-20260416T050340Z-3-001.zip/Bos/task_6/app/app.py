from flask import Flask, jsonify, render_template
import os
import psycopg2

app = Flask(__name__)


def get_connection():
    return psycopg2.connect(
        dbname=os.getenv("POSTGRES_DB"),
        user=os.getenv("POSTGRES_USER"),
        password=os.getenv("POSTGRES_PASSWORD"),
        host=os.getenv("DB_HOST"),
        port=os.getenv("DB_PORT")
    )


@app.route("/")
def home():
    try:
        conn = get_connection()
        cur = conn.cursor()

        cur.execute("""
            SELECT id, product_name, category, demand_value
            FROM demand
            ORDER BY id;
        """)
        product_rows = cur.fetchall()

        products = []
        for row in product_rows:
            products.append({
                "id": row[0],
                "product_name": row[1],
                "category": row[2],
                "demand_value": float(row[3])
            })

        cur.execute("""
            SELECT category, ROUND(AVG(demand_value), 2) AS avg_demand
            FROM demand
            GROUP BY category
            ORDER BY category;
        """)
        average_rows = cur.fetchall()

        averages = []
        chart_labels = []
        chart_values = []

        for row in average_rows:
            averages.append({
                "category": row[0],
                "average_demand": float(row[1])
            })
            chart_labels.append(row[0])
            chart_values.append(float(row[1]))

        cur.execute("SELECT COUNT(*) FROM demand;")
        total_products = cur.fetchone()[0]

        cur.execute("SELECT COUNT(DISTINCT category) FROM demand;")
        total_categories = cur.fetchone()[0]

        cur.execute("SELECT MAX(demand_value) FROM demand;")
        max_demand = float(cur.fetchone()[0])

        cur.execute("SELECT ROUND(AVG(demand_value), 2) FROM demand;")
        overall_avg = float(cur.fetchone()[0])

        cur.close()
        conn.close()

        return render_template(
            "index.html",
            products=products,
            averages=averages,
            total_products=total_products,
            total_categories=total_categories,
            max_demand=max_demand,
            overall_avg=overall_avg,
            chart_labels=chart_labels,
            chart_values=chart_values
        )

    except Exception as e:
        return f"Ошибка: {str(e)}", 500


@app.route("/products")
def get_products():
    try:
        conn = get_connection()
        cur = conn.cursor()

        cur.execute("""
            SELECT id, product_name, category, demand_value
            FROM demand
            ORDER BY id;
        """)
        rows = cur.fetchall()

        cur.close()
        conn.close()

        result = []
        for row in rows:
            result.append({
                "id": row[0],
                "product_name": row[1],
                "category": row[2],
                "demand_value": float(row[3])
            })

        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/average-demand")
def average_demand():
    try:
        conn = get_connection()
        cur = conn.cursor()

        cur.execute("""
            SELECT category, ROUND(AVG(demand_value), 2) AS avg_demand
            FROM demand
            GROUP BY category
            ORDER BY category;
        """)
        rows = cur.fetchall()

        cur.close()
        conn.close()

        result = []
        for row in rows:
            result.append({
                "category": row[0],
                "average_demand": float(row[1])
            })

        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__  == "__main__":
    app.run(host="0.0.0.0", port=5000)
