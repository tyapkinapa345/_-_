db = db.getSiblingDB('finance_db');

db.financial_data.insertMany([
  {
    "month": "2024-01",
    "revenue": 12000,
    "expenses": 8000,
    "profit": 4000,
    "category": "retail"
  },
  {
    "month": "2024-02",
    "revenue": 15000,
    "expenses": 9000,
    "profit": 6000,
    "category": "retail"
  },
  {
    "month": "2024-03",
    "revenue": 17000,
    "expenses": 10000,
    "profit": 7000,
    "category": "retail"
  },
  {
    "month": "2024-04",
    "revenue": 16000,
    "expenses": 9500,
    "profit": 6500,
    "category": "services"
  },
  {
    "month": "2024-05",
    "revenue": 18000,
    "expenses": 11000,
    "profit": 7000,
    "category": "services"
  },
  {
    "month": "2024-06",
    "revenue": 20000,
    "expenses": 12000,
    "profit": 8000,
    "category": "services"
  }
]);
