// 1. Показать все узлы графа
MATCH (n) RETURN n;

// 2. Показать пользователей и их посты
MATCH (u:User)-[:CREATED]->(p:Post)
RETURN u, p;

// 3. Показать посты и их хештеги
MATCH (p:Post)-[:HAS_TAG]->(h:Hashtag)
RETURN p, h;

// 4. Посчитать количество постов у каждого пользователя
MATCH (u:User)-[:CREATED]->(p:Post)
RETURN u.name AS user, count(p) AS posts_count
ORDER BY posts_count DESC, user ASC;

// 5. Анализ популярности хештегов
MATCH (p:Post)-[:HAS_TAG]->(h:Hashtag)
RETURN h.name AS hashtag, count(*) AS frequency
ORDER BY frequency DESC, hashtag ASC;
