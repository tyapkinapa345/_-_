MATCH (n) DETACH DELETE n;

MERGE (u1:User {name: 'Alice'})
MERGE (u2:User {name: 'Bob'})
MERGE (u3:User {name: 'Charlie'})

CREATE (p1:Post {id: 'p1', content: 'Learning Flask and Neo4j'})
CREATE (p2:Post {id: 'p2', content: 'Graph databases are powerful'})
CREATE (p3:Post {id: 'p3', content: 'Python for web development'})
CREATE (p4:Post {id: 'p4', content: 'AI trends in social media'})
CREATE (p5:Post {id: 'p5', content: 'Using hashtags for analytics'})

MERGE (u1)-[:CREATED]->(p1)
MERGE (u2)-[:CREATED]->(p2)
MERGE (u1)-[:CREATED]->(p3)
MERGE (u3)-[:CREATED]->(p4)
MERGE (u2)-[:CREATED]->(p5)

MERGE (h1:Hashtag {name: 'python'})
MERGE (h2:Hashtag {name: 'flask'})
MERGE (h3:Hashtag {name: 'neo4j'})
MERGE (h4:Hashtag {name: 'database'})
MERGE (h5:Hashtag {name: 'graph'})
MERGE (h6:Hashtag {name: 'web'})
MERGE (h7:Hashtag {name: 'ai'})
MERGE (h8:Hashtag {name: 'social'})
MERGE (h9:Hashtag {name: 'analytics'})

MERGE (p1)-[:HAS_TAG]->(h1)
MERGE (p1)-[:HAS_TAG]->(h2)
MERGE (p1)-[:HAS_TAG]->(h3)

MERGE (p2)-[:HAS_TAG]->(h3)
MERGE (p2)-[:HAS_TAG]->(h4)
MERGE (p2)-[:HAS_TAG]->(h5)

MERGE (p3)-[:HAS_TAG]->(h1)
MERGE (p3)-[:HAS_TAG]->(h2)
MERGE (p3)-[:HAS_TAG]->(h6)

MERGE (p4)-[:HAS_TAG]->(h7)
MERGE (p4)-[:HAS_TAG]->(h8)
MERGE (p4)-[:HAS_TAG]->(h1)

MERGE (p5)-[:HAS_TAG]->(h9)
MERGE (p5)-[:HAS_TAG]->(h8)
MERGE (p5)-[:HAS_TAG]->(h1);
