const Sale = require('../models/Sale');

const getSummaryStats = async (req, res) => {
  try {
    const sales = await Sale.find();

    const totalSalesCount = sales.length;
    const totalRevenue = sales.reduce((sum, sale) => sum + sale.totalAmount, 0);
    const averageCheck = totalSalesCount > 0 ? totalRevenue / totalSalesCount : 0;

    res.json({
      success: true,
      totalSalesCount,
      totalRevenue,
      averageCheck
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Ошибка при получении общей статистики',
      error: error.message
    });
  }
};

const getMonthlyRevenue = async (req, res) => {
  try {
    const { year, month } = req.query;

    if (!year || !month) {
      return res.status(400).json({
        success: false,
        message: 'Нужно указать year и month'
      });
    }

    const yearNumber = Number(year);
    const monthNumber = Number(month);

    const startDate = new Date(yearNumber, monthNumber - 1, 1);
    const endDate = new Date(yearNumber, monthNumber, 1);

    const monthlySales = await Sale.find({
      saleDate: {
        $gte: startDate,
        $lt: endDate
      }
    }).sort({ saleDate: -1 });

    const monthlyRevenue = monthlySales.reduce((sum, sale) => sum + sale.totalAmount, 0);
    const monthlySalesCount = monthlySales.length;
    const monthlyAverageCheck = monthlySalesCount > 0 ? monthlyRevenue / monthlySalesCount : 0;

    res.json({
      success: true,
      year: yearNumber,
      month: monthNumber,
      monthlyRevenue,
      monthlySalesCount,
      monthlyAverageCheck,
      sales: monthlySales
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Ошибка при получении месячного отчета',
      error: error.message
    });
  }
};

module.exports = {
  getSummaryStats,
  getMonthlyRevenue
};
