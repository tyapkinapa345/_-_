const Sale = require('../models/Sale');

const getAllSales = async (req, res) => {
  try {
    const sales = await Sale.find().sort({ saleDate: -1 });

    res.json({
      success: true,
      count: sales.length,
      sales
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Ошибка при получении продаж',
      error: error.message
    });
  }
};

const createSale = async (req, res) => {
  try {
    const { productName, category, quantity, price, saleDate } = req.body;

    const totalAmount = Number(quantity) * Number(price);

    const sale = await Sale.create({
      productName,
      category,
      quantity,
      price,
      totalAmount,
      saleDate
    });

    res.status(201).json({
      success: true,
      message: 'Продажа добавлена',
      sale
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Ошибка при добавлении продажи',
      error: error.message
    });
  }
};

module.exports = {
  getAllSales,
  createSale
};
