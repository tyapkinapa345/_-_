const express = require('express');
const router = express.Router();
const {
  getSummaryStats,
  getMonthlyRevenue
} = require('../controllers/statsController');

router.get('/summary', getSummaryStats);
router.get('/monthly', getMonthlyRevenue);

module.exports = router;
