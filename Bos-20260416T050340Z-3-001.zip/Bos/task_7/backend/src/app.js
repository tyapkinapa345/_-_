const express = require('express');
const cors = require('cors');
const path = require('path');
const mongoose = require('mongoose');

const salesRoutes = require('./routes/salesRoutes');
const statsRoutes = require('./routes/statsRoutes');

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, '../public')));

app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    message: 'Сервер работает',
    timestamp: new Date()
  });
});

app.get('/api/db-status', (req, res) => {
  const state = mongoose.connection.readyState;

  let status = 'unknown';

  if (state === 0) status = 'disconnected';
  if (state === 1) status = 'connected';
  if (state === 2) status = 'connecting';
  if (state === 3) status = 'disconnecting';

  res.json({
    success: true,
    databaseStatus: status
  });
});

app.use('/api/sales', salesRoutes);
app.use('/api/stats', statsRoutes);

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

module.exports = app;
